package br.com.barbara.ErrorCenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
